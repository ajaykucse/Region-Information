;
<?php $__env->startSection('content'); ?>

</head>
    <div id="login">
   		<form name='form-login'>
	      	<center><h1 id="admin-login-title">Admin Login</h1></center>
	        <span class="fontawesome-user"></span>
	        	<input type="text" id="user" placeholder="Username">
	        <span class="fontawesome-lock"></span>
	           <input type="password" id"pass" placeholder="Password"> 
	        		<input type="submit" value="Login">       	 
	    </form>
  	</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>