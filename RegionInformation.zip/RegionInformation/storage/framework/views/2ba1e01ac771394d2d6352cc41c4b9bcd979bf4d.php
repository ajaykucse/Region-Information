<!-- Modal -->
 
 <!-- <!--  <div class="modal fade" id="edit_news" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
  <!--     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update News</h4>
        </div>
        <div class="modal-body">
          <form method="post" id="frmEditNews" action="edit<?php echo $data->news_id?>">
            <div class="row">
                <?php echo e(csrf_field()); ?>

                <div class="col-lg-3 col-sm-3">
                  <div class="from-group">
                    <input type="text" id="name" placeholder="Name" class="form-control" name="name" value="<?php echo $data->name?>">
                  </div>
                </div>
                 <div class="col-lg-3 col-sm-3">
                  <div class="from-group">
                    <input type="text" name="type" id="Type" placeholder="Langauge" class="form-control" value="<?php echo $data->type?>">
                  </div>
                </div>
                 <div class="col-lg-3 col-sm-3">
                  <div class="from-group">
                    <input type="text" name="url" id="url" placeholder="URL" class="form-control" value="<?php echo $data->url?>">
                  </div>
                </div>
                 <div class="col-lg-3 col-sm-3">
                  <div class="from-group">
                    <input type="text" name="photo" id="photo" placeholder="Image" class="form-control" value="<?php echo $data->photo?>">
                  </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <input type="submit" name="Save" id="save" class="btn btn-primary">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
          </form> 
      </div>
      
    </div>
  </div> -->