<div class="container" style="background-color:#EEEEEE; padding: 0; ">
	<div class="row no-gutter" >
		<div class="col-md-3 ">
			<div class="panel panel-success">
				<div class="panel-heading text-center">
					<h4>
						News
						<i class="fa fa-caret-right" aria-hidden="true"></i>
					</h4>
				</div>
				<div class="panel-body  flex-grow">
				 	<div class="well well-sm" style="background:#FFFFFF; text-decoration: none;">
						<?php $__empty_1 = true; $__currentLoopData = $allNewsSites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allNewsSite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<a href="<?php echo e($allNewsSite->url); ?>" target="_blank" ><?php echo e($allNewsSite->name); ?><span class="badge"></span></a><br><br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<p>No Data is Found</p>
						<?php endif; ?>
				</div>
				</div>
			</div>
		</div>
    <div class="col-md-9">
		<div class="row" > <!-- .no-gutter .news_content{} -->
			<?php $__empty_1 = true; $__currentLoopData = $allNewsSites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allNewsSite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="col-md-3 news_content" style="padding:0">
					<div class="thumbnail" style="margin:0px auto;">
						<a href="<?php echo e($allNewsSite->url); ?>" target="_blank" title="<?php echo e($allNewsSite->name); ?>">
						<img class="img-responsive" src="<?php echo e(asset('images/news/'.$allNewsSite->photo)); ?>" alt="<?php echo e($allNewsSite->name); ?>" style="width:60px;height:60px;">
							<div class="caption">
								<h3></h3>
								<p></p>
							</div>
							</a>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<P>No Data to View</P>
			<?php endif; ?>
		</div>
    </div><!--col-md-9 end -->
	</div>
</div>
