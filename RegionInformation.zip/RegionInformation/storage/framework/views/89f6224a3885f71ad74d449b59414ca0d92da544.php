<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>>
	<title></title>
</head>
<body>
<div class="container">
	<div class="col-lg-4">
		<?php echo e(form::open(array('url'=>'','files'=>true))); ?>

		<div class="form-group">
			<label for=""></label>
			<select class="form-control input sm" name="">
				<?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($reg->location_id); ?>"><?php echo e($reg->city_region); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
	</div>
</div>
</body>
</html>