<div class="container" style="background-color:#EEEEEE; padding: 0; ">
	<div class="row no-gutter" >
		<div class="col-md-3 ">
			<div class="panel panel-success">
				<div class="panel-heading text-center">
					<h4>
						News
						<i class="fa fa-caret-right" aria-hidden="true"></i>
					</h4>
				</div>
				<div class="panel-body  flex-grow">
				 	<div class="well well-sm" style="background:#FFFFFF; text-decoration: none;">
					<a href="http://bangla.bdnews24.com" target="_blank" >Bd News 24.com <span class="badge"></span></a><br><br>
					<a href="http://www.prothom-alo.com" target="_blank">Prothom Alo <span class="badge"></span></a><br><br>
					<a href="http://www.banglatribune.com" target="_blank" >Bangla Tribue <span class="badge"></span></a><br><br>
					<a href="http://www.bd24live.com/bangla" target="_blank" >Bd 24 live.com <span class="badge"></span></a><br><br>
					<a href="http://www.banglanews24.com" target="_blank" >Bangla News24.com <span class="badge"></span></a><br><br>
					<a href="http://bangla.samakal.net" target="_blank" >Samakal <span class="badge"></span></a><br><br>
					<a href="http://www.kalerkantho.com" target="_blank" >Kalerkhonto <span class="badge"></span></a><br><br>
					<a href="http://www.daily-sun.com" target="_blank" >Dailysun <span class="badge"></span></a><br><br>
					<a href="http://www.newstoday.com.bd" target="_blank">Newstoday <span class="badge"></span></a><br><br>
					<a href="http://www.bd-pratidin.com" target="_blank" >Bangladeshpatidin <span class="badge"></span></a><br><br>
					<a href="http://www.weeklyholiday.com" target="_blank" >Holiday <span class="badge"></span></a><br><br>
					<a href="http://www.w3newspapers.com/bangladesh" target="_blank">BD Newspaper <span class="badge"></span></a><br><br>
				</div>
				</div>
			</div>
		</div>
    <div class="col-md-9">
		  <div class="row" > <!-- .no-gutter .news_content{} -->
  			<div class="col-md-3 news_content" style="padding:0">
    			<div class="thumbnail" style="margin:0px auto;">
    				<a href="http://bangla.bdnews24.com" target="_blank" title="BdNews24.com">
      				<img class="img-responsive" src="_/images/banglanews.png" alt="BdNews24.com" style="width:60px;height:60px;">
      					<div class="caption">
      						<h3></h3>	 
      						<p></p>
      					</div>
      					</a>
    			</div>
  			</div>
  			<div class="col-md-3 news_content" style="padding:0">
    			<div class="thumbnail" style="margin:0px auto;">
    			<a href="http://www.prothom-alo.com" target="_blank" title="Prothom Alo">
      				<img class="img-responsive" src="_/images/prothomAlo.png" alt="Prothom Alo" style="width:60px;height:60px;">
      					<div class="caption">
        					<h3></h3>
        						<p></p>
        						 
      					</div>
      					</a>
    			</div>
  			</div>
  			<div class="col-md-3 news_content" style="padding:0">
    			<div class="thumbnail" style="margin:0px auto;">
    				<a href="http://www.banglatribune.com/" target="_blank" title="Bangla Tribue">
      				<img class="img-responsive" src="_/images/banglaTribune.png" alt="Bangla Tribue" style="width:60px;height:60px;">
      					<div class="caption">
        					<h3></h3>
        						<p></p>
        						 
      					</div>
      					</a>
    			</div>
  			</div>
  			<div class="col-md-3 news_content" style="padding-left:0;">
      			<div class="thumbnail" style="margin:0px auto;">
      				<a href="http://www.bd24live.com/bangla" target="_blank" title="Bd 24 live.com">
        				<img class="img-responsive" src="_/images/bd24live.jpg" alt="Bd 24 live.com" style="width:60px;height:60px;">
        					<div class="caption">
          					<h3></h3>
          						<p></p>
          						 
        					</div>
        				</a>
      			</div>
  			</div>
 






		  </div>	
	
    </div><!--col-md-9 end -->
	</div>
</div>
