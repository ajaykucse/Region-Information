<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <link rel="icon" type="image/gif/png" href="_/images/urllogo.ico">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>



 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
        <title>RI Center</title>
    </head>
    <body>
    
          <?php echo $__env->make('layouts.common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.common.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.common.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.hospital', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.gov-office', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.non-gov-office', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.hotel-restaurant', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.travel-tour', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.market', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.mcc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->make('layouts.panel.education', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
          <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

    </body>
</html>
