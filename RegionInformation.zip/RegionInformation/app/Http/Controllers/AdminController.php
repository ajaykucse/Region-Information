<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Auth;
use DB;

class AdminController extends Controller
{

    public function dashboard()
    {
    	$data['data'] = DB::table('location')->paginate(5);


        if(count($data) > 0) 
        {
            return view('admin.dashboard',$data);
            
        }
        else
        {
            return view('admin.region.location');

        }


        // Data show for Hospital

        $da['da'] = DB::table('hospital')->get();


        if(count($da) > 0) 
        {
            return view('admin.dashboard',$da);
            
        }
        else
        {
            return view('admin.health-care.hospital.hospital');

        }

        // For news

        $data['data'] = DB::table('news')->get();


        if(count($data) > 0) 
        {
            return view('admin.dashboard',$data);
            
        }
        else
        {
            return view('admin.news.news');

        }

        //return view ('admin.dashboard', array('user' => Auth::user()));
    }
    public function storeLocation(Request $request)
    {
        $name = $request->input('name');
        $contact = $request->input('contact');
        $url  = $request->input('url');
        $details = $request->input('details');
        $location_id = $request->input('location_id');
        $da  = array('name'=>$name,'contact'=>$contact,'url'=>$url,'details'=>$details,'location_id'=>$location_id);
        DB::table('hospital')->insert($da);
        echo "Success";
        // return redirect('/dashboard');
    }
        public function store(Request $req)
    {
        $name = $req->input('name');
        $contact = $req->input('contact');
        $url  = $req->input('url');
        $details = $req->input('details');
        // $photo = $req->input('photo');

        $da  = array('name'=>$name,'contact'=>$contact,'url'=>$url,'details'=>$details);
        DB::table('hospital')->insert($da);
        echo "Success";
        $this->getData();
        // return redirect('/dashboard');
    }

    public function insert(Request $request)
    {
    	$country_code = $request->input('country_code');
        $country      = $request->input('country');
        $city_region  = $request->input('city_region');
        $zip          = $request->input('zip');

        $data  = array('country_code'=>$country_code,'country'=>$country,'city_region'=>$city_region,'zip'=>$zip);
        DB::table('location')->insert($data);
        echo "Success";
        $this->getData();
    }
    public function delete($location_id)
    {
        DB::table('location')->where('location_id',$location_id)->delete();
        //$this->getData();
    }
    public function edit($location_id)
    {
        $data= location::find($location_id);
        return view('admin.region.editLocation',['data'=>$data]);
    }







    
}
