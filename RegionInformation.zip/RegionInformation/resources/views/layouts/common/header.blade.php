<div class="cotainer">
  <div class="row" class="jumbotron" style="margin:15px;padding:15px; background:transparent !important">
				<div class="col-md-2">
					<div class="img-responsive span-6 pull-left">
						<a href="#"> <img src="_/images/logo_header.png" class="img-responsive img-rounded-circle"/></a>
					</div>
				</div>

				<div class="col-md-8">
          <div class = "input-group pull-left" style="box-shadow: 0px 2px 25px rgba(0, 0, 0, .25); ">
            <input placeholder="Search" type = "text" class = "form-control" size="37">
              <i class="glyphicon glyphicon-search form-control-feedback"></i>
          </div><!-- /input-group -->

      		<div class="input-group">
	          <select class="form-control" name="color">
      				<option value="">All Category</option>
      				<option value="black">News</option>
      				<option value="green">Hospital</option>
      				<option value="red">Gov-Office</option>
      				<option value="yellow">Non-Gov-Office</option>
      				<option value="white">Hotel & Restaurant</option>
      				<option value="white">Travel & Tour</option>
      				<option value="white">Market</option>
      				<option value="white">MCC</option>
      				<option value="white">Education</option>
  				  </select>
						<div class="input-group-btn">
  						<button class="btn btn-primary" type="submit">
  							<span class="glyphicon glyphicon-search"></span>
  						</button>
						</div>
				  </div>
			  </div>
				<div class="col-md-2">
		   		<!-- <div class="Advanced-search"> -->
			 		  <a href=""><h4> Advanced Search</h4> </a>
          <!-- </div> -->
				</div>
	</div>  
</div>