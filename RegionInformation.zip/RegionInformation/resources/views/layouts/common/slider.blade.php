<div class="container">
	<div class="row">
		<div class="col-md-8" style="margin: 0;padding: 0;">
			<div class="carousel slide article-slide" id="myCarousel">
      			<div class="carousel-inner cont-slider">
    
        			<div class="item active">
          				<img src="_/images/news.jpg">
        			</div>
        			<div class="item">
          				<img src="_/images/hospital.jpg">
        			</div>
        			<div class="item">
          				<img src="_/images/education.jpg">
        			</div>   
        			            
      			</div>
       
     				 <!-- Indicators -->
      			<ol class="carousel-indicators visible-lg visible-md">
        			<li class="active" data-slide-to="0" data-target="#myCarousel">
         			 	<img src="_/images/news.jpg">
        			</li>
        			<li class="" data-slide-to="1" data-target="#myCarousel">
         				<img src="_/images/hospital.jpg">
        			</li>
        			<li class="" data-slide-to="2" data-target="#myCarousel">
         		 		<img src="_/images/education.jpg">
        			</li>     
      			</ol>   
			</div>
    	</div>
		<div class="col-sm-4">
			<!-- this script got from www.htmlbestcodes.com-Coded by: Krishna Eydat -->
			<!-- <center> -->
			<script language="javascript" type="text/javascript">
				var day_of_week = new Array('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
				var month_of_year = new Array('January','February','March','April','May','June','July','August','September','October','November','December');

					//  DECLARE AND INITIALIZE VARIABLES
				var Calendar = new Date();

				var year = Calendar.getFullYear();     // Returns year
				var month = Calendar.getMonth();    // Returns month (0-11)
				var today = Calendar.getDate();    // Returns day (1-31)
				var weekday = Calendar.getDay();    // Returns day (1-31)

				var DAYS_OF_WEEK = 7;    // "constant" for number of days in a week
				var DAYS_OF_MONTH = 31;    // "constant" for number of days in a month
				var cal;    // Used for printing

				Calendar.setDate(1);    // Start the calendar day at '1'
				Calendar.setMonth(month);    // Start the calendar month at now

					/* VARIABLES FOR FORMATTING
					NOTE: You can format the 'BORDER', 'BGCOLOR', 'CELLPADDING', 'BORDERCOLOR'
      				tags to customize your caledanr's look. */

				var TR_start = '<TR>';
				var TR_end = '</TR>';
				var highlight_start = '<TD WIDTH="30"><TABLE CELLSPACING=0 BORDER=1 BGCOLOR=BBBBBB BORDERCOLOR=dddddd><TR><TD WIDTH=20><B><CENTER>';
				var highlight_end   = '</CENTER></TD></TR></TABLE></B>';
				var TD_start = '<TD WIDTH="30"><CENTER>';
				var TD_end = '</CENTER></TD>';

				/* BEGIN CODE FOR CALENDAR
					NOTE: You can format the 'BORDER', 'BGCOLOR', 'CELLPADDING', 'BORDERCOLOR'
					tags to customize your calendar's look.*/

				cal =  '<TABLE BORDER=3 CELLSPACING=0 CELLPADDING=0 BORDERCOLOR=333333><TR><TD>';
				cal += '<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=2>' + TR_start;
				cal += '<TD COLSPAN="' + DAYS_OF_WEEK + '" BGCOLOR="#EFEFEF"><CENTER><B>';
				cal += month_of_year[month]  + '   ' + year + '</B>' + TD_end + TR_end;
				cal += TR_start;

					//   DO NOT EDIT BELOW THIS POINT  //

					// LOOPS FOR EACH DAY OF WEEK
				for(index=0; index < DAYS_OF_WEEK; index++)
					{

							// BOLD TODAY'S DAY OF WEEK
						if(weekday == index)
							cal += TD_start + '<B>' + day_of_week[index] + '</B>' + TD_end;

							// PRINTS DAY
						else
							cal += TD_start + day_of_week[index] + TD_end;
					}

					cal += TD_end + TR_end;
					cal += TR_start;

						// FILL IN BLANK GAPS UNTIL TODAY'S DAY
					for(index=0; index < Calendar.getDay(); index++)
						cal += TD_start + '  ' + TD_end;

							// LOOPS FOR EACH DAY IN CALENDAR
						for(index=0; index < DAYS_OF_MONTH; index++)
							{
						if( Calendar.getDate() > index )
							{
  								// RETURNS THE NEXT DAY TO PRINT
  								week_day =Calendar.getDay();

  								// START NEW ROW FOR FIRST DAY OF WEEK
  								if(week_day == 0)
  									cal += TR_start;

  								if(week_day != DAYS_OF_WEEK)
  									{
  											// SET VARIABLE INSIDE LOOP FOR INCREMENTING PURPOSES
  											var day  = Calendar.getDate();

  											// HIGHLIGHT TODAY'S DATE
  										if( today==Calendar.getDate() )
  											cal += highlight_start + day + highlight_end + TD_end;

  											// PRINTS DAY
  										else
  											cal += TD_start + day + TD_end;
  									}

  										// END ROW FOR LAST DAY OF WEEK
  								if(week_day == DAYS_OF_WEEK)
 									 cal += TR_end;
  							}
 							// INCREMENTS UNTIL END OF THE MONTH
  							Calendar.setDate(Calendar.getDate()+1);

						}// end for loop
					cal += '</TD></TR></TABLE></TABLE>';
					//  PRINT CALENDAR
				document.write(cal);
				//  End 
 </script>

<!-- </center> 
-->
 
</div>
</div>
</div>
<br>

<style type="text/css">
	
 
/*#####################
Additional Styles (required)
#####################*/
#myCarousel .carousel-indicators {
    bottom: 0;
    left: 10px;
    margin-left: 5px;
    width: 100%;
}
#myCarousel .carousel-indicators li {
    border: medium none;
    border-radius: 0;
    float: left;
    height: 44px;
    margin-bottom: 5px;
    margin-left: 0;
    margin-right: 5px !important;
    margin-top: 0;
    width: 120px;
}
#myCarousel .carousel-indicators img {
    border: 2px solid #FFFFFF;
    float: left;
    height: 44px;
    left: 0;
    width: 120px;
}
#myCarousel .carousel-indicators .active img {
    border: 2px solid #39b3d7;
}
table, th, td {
    border: 1px solid black;

}

tr:hover {background-color: #f5f5f5}

}
tr:nth-child(even) {background-color: #f2f2f2}
th {
    background-color: #4CAF50;
    color: white;
}


</style>


<script type="text/javascript">
	
	$('#myCarousel').carousel({
		interval:   3000
	});
</script>

  
