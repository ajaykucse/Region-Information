<div class="container" style="background-color:#EEEEEE; padding: 0; ">
	<div class="row no-gutter" >
		<div class="col-md-3 ">
			<div class="panel panel-success">
				<div class="panel-heading text-center">
					<h4>
						News
						<i class="fa fa-caret-right" aria-hidden="true"></i>
					</h4>
				</div>
				<div class="panel-body  flex-grow">
				 	<div class="well well-sm" style="background:#FFFFFF; text-decoration: none;">
						@forelse($allNewsSites as $allNewsSite)
							<a href="{{$allNewsSite->url}}" target="_blank" >{{$allNewsSite->name}}<span class="badge"></span></a><br><br>
						@empty
							<p>No Data is Found</p>
						@endif
				</div>
				</div>
			</div>
		</div>
    <div class="col-md-9">
		<div class="row" > <!-- .no-gutter .news_content{} -->
			@forelse($allNewsSites as $allNewsSite)
				<div class="col-md-3 news_content" style="padding:0">
					<div class="thumbnail" style="margin:0px auto;">
						<a href="{{$allNewsSite->url}}" target="_blank" title="{{$allNewsSite->name}}">
						<img class="img-responsive" src="{{asset('images/news/'.$allNewsSite->photo)}}" alt="{{$allNewsSite->name}}" style="width:60px;height:60px;">
							<div class="caption">
								<h3></h3>
								<p></p>
							</div>
							</a>
					</div>
				</div>
			@empty
				<P>No Data to View</P>
			@endif
		</div>
    </div><!--col-md-9 end -->
	</div>
</div>
