<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'PublicHomeController@index');

Route::get('/sign-in', function () {
    return view('auth/login');
});
// Route::get('/dashboard', function () {
//     return view('admin.dashboard');
// });
 
Auth::routes();

Route::get('/home', 'HomeController@index');
Route::get('/index',function(){
	$region = DB::table('location')->get();
	return view::make('index')->with('region',$region);



});
 
Route::get('dashboard', 'AdminController@dashboard');
Route::post('store/details', 'AdminController@storeLocation');

// Auth:: routes();

// Route::get('master', 'HomeController@admin'); 


Auth::routes();

Route::get('/home', 'HomeController@index');

// For Region & City 

Route::get('/location','LocationController@getData');
Route::post('/insert','LocationController@insert');
Route::get('/delete/{id}','LocationController@delete');
Route::get('/edit','LocationController@edit');

// For News

Route::get('/news','NewsController@create');
Route::post('/insert','NewsController@store');
Route::get('/news','NewsController@getData');
// Route::post('/insert','NewsController@insert');
// Route::get('/delete/{id}','NewsController@delete');
// Route::get('/edit','NewsController@edit');

Route::get('/hospital','HospitalController@index');
Route::post('/store','HospitalController@store');


 

Auth::routes();

Route::get('/home', 'HomeController@index');
